# Quartz

## [3.6.9](https://github.com/Nevcairiel/Quartz/tree/3.6.9) (2022-02-23)
[Full Changelog](https://github.com/Nevcairiel/Quartz/compare/3.6.8...3.6.9) [Previous Releases](https://github.com/Nevcairiel/Quartz/releases)

- Update TOC  
- Add fallback channeling table  
