# SexyMap

## [v9.2.4](https://github.com/funkydude/SexyMap/tree/v9.2.4) (2022-03-28)
[Full Changelog](https://github.com/funkydude/SexyMap/compare/v9.2.3...v9.2.4) [Previous Releases](https://github.com/funkydude/SexyMap/releases)

- Add remaining missing textures for classic  
- Don't need 2 separate files for borders module  
